#ifndef TEST_FULL_RUN
#define TEST_FULL_RUN

// function to test run with pid values
int testPIDRun();

// function to test run with nn system
testNNRun();

#endif