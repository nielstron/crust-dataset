#ifndef GENERAL_MATH_H
#define GENERAL_MATH_H

// function to create float in range
float createRandomFloat(float min, float max);

#endif