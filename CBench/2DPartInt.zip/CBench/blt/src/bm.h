void bm_init();
void bm_report(char *msg);
void bm_read_keys(void (*cb)(char **key, int m));
