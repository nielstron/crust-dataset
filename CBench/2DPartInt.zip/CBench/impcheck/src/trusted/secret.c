
#include "secret.h"

const unsigned char SECRET_KEY[] = {
    86, 93, 1, 209, 112, 176, 13, 40,
    168, 223, 25, 22, 134, 58, 21, 211
};
