#include <stdint.h>

char* print_bin(uint64_t n);