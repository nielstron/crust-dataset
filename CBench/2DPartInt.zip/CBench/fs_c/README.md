fs.c [![Build Status](https://travis-ci.org/jwerle/fs.c.png?branch=master)](https://travis-ci.org/jwerle/fs.c)
==========================

File system API much like Node's fs module (synchronous)
